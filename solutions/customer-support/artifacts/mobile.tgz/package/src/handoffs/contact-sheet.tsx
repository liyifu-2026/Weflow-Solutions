/**
 * 联系人 Sheet（全屏 Modal）
 * 第一屏回答「这个人是谁 + 最近发生过什么」：资料摘要 + 历史会话列表。
 * 点历史进入只读会话详情（无 Composer/无任何操作入口），关闭即回原会话。
 * 编辑资料通过 onRequestEdit 回调交给页面复用既有资料编辑弹窗。
 */
import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { ArrowLeft } from "phosphor-react-native/src/icons/ArrowLeft";
import { CaretRight } from "phosphor-react-native/src/icons/CaretRight";
import { ChatCircleDots } from "phosphor-react-native/src/icons/ChatCircleDots";
import type { MobileSession } from "@/auth/session";
import {
  getContactProfile,
  getTranscript,
  listContactHistory,
  type ContactConversationSummary,
  type ContactProfile,
  type ServerMessage,
} from "@/conversations/api";
import { contactDisplayName } from "@/conversations/contact-profile";
import { MediaImage } from "@/media/media-image";
import { MediaViewerModal } from "@/media/media-viewer";
import { VoiceBubble } from "@/media/voice-bubble";
import { formatDay, formatTime } from "@/ui/format";
import type { ThemeColors } from "@/ui/theme";
import { useTheme, useThemedStyles } from "@/ui/theme-context";
import { uiTokens } from "@/ui/tokens";
import { UserAvatar } from "@/ui/user-avatar";

export function ContactSheet({
  visible,
  session,
  conversationId,
  onClose,
  onRequestEdit,
  onNavigateToConversation,
}: {
  visible: boolean;
  session: MobileSession;
  conversationId: string;
  onClose: () => void;
  onRequestEdit: (profile: ContactProfile) => void;
  onNavigateToConversation?: (conversationId: string) => void;
}) {
  const { colors } = useTheme();
  const styles = useThemedStyles(createStyles);
  const [profile, setProfile] = useState<ContactProfile>();
  const [history, setHistory] = useState<ContactConversationSummary[]>([]);
  const [error, setError] = useState<string>();
  const [openedConversation, setOpenedConversation] = useState<{
    conversationId: string;
    name: string;
  }>();
  const [showingAll, setShowingAll] = useState(false);
  const [allCursor, setAllCursor] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    void (async () => {
      let loadedProfile: ContactProfile | undefined;
      try {
        loadedProfile = await getContactProfile(session, conversationId);
        if (!active) return;
        setProfile(loadedProfile);
        setError(undefined);
      } catch {
        if (active) setError("联系人资料暂时无法加载，请稍后重试。");
        return;
      }
      // 历史对话加载失败不影响资料展示
      if (!loadedProfile) return;
      try {
        const page = await listContactHistory(
          session,
          loadedProfile.contactId,
          undefined,
          10,
        );
        if (!active) return;
        setHistory(page.conversations);
        setAllCursor(page.nextCursor);
      } catch {
        // 历史加载失败静默处理，资料区仍可展示
      }
    })();
    return () => {
      active = false;
    };
  }, [visible, session, conversationId]);

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="fullScreen"
      onRequestClose={onClose}
    >
      <SafeAreaView style={styles.page}>
        {openedConversation ? (
          <ReadOnlyConversation
            session={session}
            conversationId={openedConversation.conversationId}
            name={openedConversation.name}
            onBack={() => setOpenedConversation(undefined)}
          />
        ) : showingAll ? (
          <AllHistory
            session={session}
            contactId={profile?.contactId}
            name={profile ? displayName(profile) : "联系人"}
            currentConversationId={conversationId}
            initial={history}
            initialCursor={allCursor}
            onOpen={(item) =>
              setOpenedConversation({
                conversationId: item.conversationId,
                name: profile ? displayName(profile) : "联系人",
              })
            }
            onBack={() => setShowingAll(false)}
          />
        ) : (
          <>
            <View style={styles.header}>
              <Pressable
                accessibilityLabel="关闭联系人"
                hitSlop={12}
                onPress={onClose}
                style={styles.headerButton}
              >
                <ArrowLeft size={23} color={colors.ink} />
              </Pressable>
              <Text style={styles.headerTitle}>联系人</Text>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="编辑联系人资料"
                hitSlop={12}
                disabled={!profile}
                onPress={() => {
                  if (profile) onRequestEdit(profile);
                }}
                style={styles.headerButton}
              >
                <Text
                  style={[
                    styles.editText,
                    !profile && styles.editTextDisabled,
                  ]}
                >
                  编辑
                </Text>
              </Pressable>
            </View>
            <ScrollView contentContainerStyle={styles.content}>
              {error ? (
                <Text style={styles.error}>{error}</Text>
              ) : !profile ? (
                <View style={styles.loading}>
                  <ActivityIndicator color={colors.blue} />
                </View>
              ) : (
                <>
                  <View style={styles.profileBlock}>
                    <UserAvatar
                      contactId={profile.contactId}
                      fallbackName={displayName(profile)}
                      sessionToken={session.sessionToken}
                      size={52}
                    />
                    <Text style={styles.name}>{displayName(profile)}</Text>
                    {profile.channelRemark ? (
                      <Text style={styles.meta}>{profile.channelRemark}</Text>
                    ) : null}
                    {profile.note ? (
                      <View style={styles.fieldBlock}>
                        <Text style={styles.fieldLabel}>备注</Text>
                        <Text style={styles.fieldText}>{profile.note}</Text>
                      </View>
                    ) : null}
                    {profile.tags.length ? (
                      <View style={styles.fieldBlock}>
                        <Text style={styles.fieldLabel}>标签</Text>
                        <View style={styles.tagRow}>
                          {profile.tags.map((tag) => (
                            <View key={tag} style={styles.tag}>
                              <Text style={styles.tagText}>{tag}</Text>
                            </View>
                          ))}
                        </View>
                      </View>
                    ) : null}
                    {onNavigateToConversation ? (
                      <Pressable
                        accessibilityRole="button"
                        accessibilityLabel="前往对话"
                        onPress={() => onNavigateToConversation(conversationId)}
                        style={({ pressed }) => [
                          styles.goToConversationButton,
                          pressed && styles.goToConversationButtonPressed,
                        ]}
                      >
                        <ChatCircleDots size={18} color={colors.onPrimary} />
                        <Text style={styles.goToConversationText}>前往对话</Text>
                      </Pressable>
                    ) : null}
                  </View>
                  <Text style={styles.sectionLabel}>历史对话</Text>
                  {history.length === 0 ? (
                    <Text style={styles.empty}>暂无历史会话</Text>
                  ) : (
                    history.map((item) => (
                      <Pressable
                        key={item.conversationId}
                        accessibilityRole="button"
                        accessibilityLabel={`查看历史会话 ${item.conversationId}`}
                        onPress={() =>
                          setOpenedConversation({
                            conversationId: item.conversationId,
                            name: displayName(profile),
                          })
                        }
                        style={({ pressed }) => [
                          styles.historyRow,
                          pressed && styles.rowPressed,
                        ]}
                      >
                        <View style={styles.historyCopy}>
                          <Text style={styles.historyText} numberOfLines={1}>
                            {item.latestMessageText || "（无消息）"}
                          </Text>
                          <Text style={styles.historyMeta}>
                            {item.conversationId === conversationId
                              ? "当前会话"
                              : handoffStatusCopy(item.handoffStatus)}
                            {item.latestMessageAt
                              ? ` · ${formatTime(item.latestMessageAt)}`
                              : ""}
                          </Text>
                        </View>
                        <CaretRight size={16} color={colors.blue} />
                      </Pressable>
                    ))
                  )}
                  {history.length > 0 ? (
                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel="查看全部历史"
                      onPress={() => setShowingAll(true)}
                      style={({ pressed }) => [
                        styles.allHistoryRow,
                        pressed && styles.rowPressed,
                      ]}
                    >
                      <Text style={styles.allHistoryText}>查看全部历史</Text>
                      <CaretRight size={16} color={colors.blue} />
                    </Pressable>
                  ) : null}
                </>
              )}
            </ScrollView>
          </>
        )}
      </SafeAreaView>
    </Modal>
  );
}

/** 联系人完整历史（游标分页，按最近消息倒序） */
function AllHistory({
  session,
  contactId,
  name,
  currentConversationId,
  initial,
  initialCursor,
  onOpen,
  onBack,
}: {
  session: MobileSession;
  contactId?: string;
  name: string;
  currentConversationId: string;
  initial: ContactConversationSummary[];
  initialCursor: string | null;
  onOpen: (item: ContactConversationSummary) => void;
  onBack: () => void;
}) {
  const { colors } = useTheme();
  const styles = useThemedStyles(createStyles);
  const [items, setItems] = useState(initial);
  const [cursor, setCursor] = useState<string | null>(initialCursor);
  const [loadingMore, setLoadingMore] = useState(false);
  const [loadError, setLoadError] = useState<string>();

  const loadMore = async () => {
    if (!contactId || !cursor || loadingMore) return;
    setLoadingMore(true);
    setLoadError(undefined);
    try {
      const page = await listContactHistory(session, contactId, cursor);
      setItems((current) => [...current, ...page.conversations]);
      setCursor(page.nextCursor);
    } catch {
      setLoadError("加载失败，请重试。");
    } finally {
      setLoadingMore(false);
    }
  };

  return (
    <View style={styles.page}>
      <View style={styles.header}>
        <Pressable
          accessibilityLabel="返回联系人"
          hitSlop={12}
          onPress={onBack}
          style={styles.headerButton}
        >
          <ArrowLeft size={23} color={colors.ink} />
        </Pressable>
        <View style={styles.headerCopy}>
          <Text style={styles.headerTitle}>{name}</Text>
          <Text style={styles.readOnlyTag}>历史对话</Text>
        </View>
        <View style={styles.headerButton} />
      </View>
      <ScrollView contentContainerStyle={styles.content}>
        {items.length === 0 ? (
          <Text style={styles.empty}>暂无历史会话</Text>
        ) : (
          items.map((item) => (
            <Pressable
              key={item.conversationId}
              accessibilityRole="button"
              accessibilityLabel={`查看历史会话 ${item.conversationId}`}
              onPress={() => onOpen(item)}
              style={({ pressed }) => [
                styles.historyRow,
                pressed && styles.rowPressed,
              ]}
            >
              <View style={styles.historyCopy}>
                <Text style={styles.historyText} numberOfLines={1}>
                  {item.latestMessageText || "（无消息）"}
                </Text>
                <Text style={styles.historyMeta}>
                  {item.conversationId === currentConversationId
                    ? "当前会话"
                    : item.handoffStatus
                      ? "人工处理"
                      : "Agent 自动处理"}
                  {item.latestMessageAt
                    ? ` · ${formatDay(item.latestMessageAt)} ${formatTime(item.latestMessageAt)}`
                    : ""}
                </Text>
              </View>
              <CaretRight size={16} color={colors.blue} />
            </Pressable>
          ))
        )}
        {cursor ? (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="加载更多历史"
            disabled={loadingMore}
            onPress={() => void loadMore()}
            style={styles.loadMoreRow}
          >
            {loadingMore ? (
              <ActivityIndicator size="small" color={colors.blue} />
            ) : (
              <Text style={styles.loadMoreText}>
                {loadError ?? "加载更多"}
              </Text>
            )}
          </Pressable>
        ) : null}
      </ScrollView>
    </View>
  );
}

/** 只读历史会话详情：无 Composer、无任何操作入口 */
function ReadOnlyConversation({
  session,
  conversationId,
  name,
  onBack,
}: {
  session: MobileSession;
  conversationId: string;
  name: string;
  onBack: () => void;
}) {
  const { colors } = useTheme();
  const styles = useThemedStyles(createStyles);
  const [messages, setMessages] = useState<ServerMessage[]>();
  const [error, setError] = useState<string>();
  const [lightboxMediaId, setLightboxMediaId] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    void getTranscript(session, conversationId)
      .then((page) => {
        if (active) setMessages(page.messages);
      })
      .catch(() => {
        if (active) setError("历史会话暂时无法加载。");
      });
    return () => {
      active = false;
    };
  }, [session, conversationId]);

  return (
    <View style={styles.page}>
      <View style={styles.header}>
        <Pressable
          accessibilityLabel="返回联系人"
          hitSlop={12}
          onPress={onBack}
          style={styles.headerButton}
        >
          <ArrowLeft size={23} color={colors.ink} />
        </Pressable>
        <View style={styles.headerCopy}>
          <Text style={styles.headerTitle}>{name}</Text>
          <Text style={styles.readOnlyTag}>历史记录 · 只读</Text>
        </View>
        <View style={styles.headerButton} />
      </View>
      {error ? (
        <Text style={styles.error}>{error}</Text>
      ) : !messages ? (
        <View style={styles.loading}>
          <ActivityIndicator color={colors.blue} />
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.transcript}>
          {messages.length === 0 ? (
            <Text style={styles.empty}>暂无消息</Text>
          ) : (
            messages.map((message) => (
              <View
                key={message.messageId}
                style={[
                  styles.messageRow,
                  message.direction === "outbound"
                    ? styles.messageRowOutbound
                    : undefined,
                ]}
              >
                <View
                  style={[
                    styles.messageBubble,
                    message.direction === "outbound"
                      ? styles.messageBubbleOutbound
                      : undefined,
                  ]}
                >
                  {message.contentType === "image" && message.mediaId ? (
                    <MediaImage
                      session={session}
                      mediaId={message.mediaId}
                      offline={false}
                      style={styles.historyImage}
                      onOpen={() => setLightboxMediaId(message.mediaId ?? null)}
                    />
                  ) : message.contentType === "voice" && message.mediaId ? (
                    <VoiceBubble
                      session={session}
                      mediaId={message.mediaId}
                      offline={false}
                    />
                  ) : message.contentType !== "text" ? (
                    <Text style={styles.messageNonText}>[文件]</Text>
                  ) : (
                    <Text style={styles.messageText}>{message.text}</Text>
                  )}
                  <Text style={styles.messageTime}>
                    {formatTime(message.occurredAt)}
                  </Text>
                </View>
              </View>
            ))
          )}
        </ScrollView>
      )}
      {lightboxMediaId ? (
        <MediaViewerModal
          session={session}
          mediaId={lightboxMediaId}
          onClose={() => setLightboxMediaId(null)}
        />
      ) : null}
    </View>
  );
}

function displayName(profile: ContactProfile): string {
  return contactDisplayName(profile);
}

function handoffStatusCopy(status: string | null): string {
  if (!status) return "Agent 处理";
  if (status === "in_progress") return "人工处理";
  return "已结束";
}

const createStyles = (colors: ThemeColors) =>
  StyleSheet.create({
    page: { flex: 1, backgroundColor: colors.canvas },
    header: {
      minHeight: 52,
      paddingHorizontal: 12,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
    },
    headerButton: {
      minWidth: 38,
      minHeight: 38,
      alignItems: "center",
      justifyContent: "center",
    },
    headerTitle: { color: colors.ink, fontSize: 16, fontWeight: "700" },
    headerCopy: { alignItems: "center" },
    readOnlyTag: { color: colors.muted, fontSize: 11, marginTop: 2 },
    editText: { color: colors.blue, fontSize: 14, fontWeight: "600" },
    editTextDisabled: { opacity: 0.4 },
    content: { padding: 20, paddingBottom: 42 },
    loading: { paddingVertical: 60, alignItems: "center" },
    error: { color: colors.red, fontSize: 13, paddingVertical: 24 },
    profileBlock: { alignItems: "flex-start", gap: 4, marginBottom: 26 },
    name: { color: colors.ink, fontSize: 19, fontWeight: "700" },
    meta: { color: colors.muted, fontSize: 13 },
    fieldBlock: { marginTop: 10, alignSelf: "stretch" },
    fieldLabel: {
      color: colors.muted,
      fontSize: 10,
      fontWeight: "600",
      marginBottom: 4,
    },
    fieldText: { color: colors.ink, fontSize: 13, lineHeight: 19 },
    tagRow: { flexDirection: "row", flexWrap: "wrap", gap: 6 },
    tag: {
      backgroundColor: colors.blueWash,
      borderRadius: 8,
      paddingHorizontal: 9,
      paddingVertical: 4,
    },
    tagText: { color: colors.blue, fontSize: 11, fontWeight: "600" },
    sectionLabel: {
      color: colors.muted,
      fontSize: 12,
      fontWeight: "700",
      marginBottom: 8,
    },
    empty: { color: colors.muted, fontSize: 13, paddingVertical: 18 },
    historyRow: {
      minHeight: 58,
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
      borderBottomWidth: StyleSheet.hairlineWidth,
      borderBottomColor: colors.rule,
    },
    rowPressed: { backgroundColor: colors.subtle },
    historyCopy: { flex: 1 },
    historyText: { color: colors.ink, fontSize: 13 },
    historyMeta: { color: colors.muted, fontSize: 11, marginTop: 3 },
    allHistoryRow: {
      minHeight: 50,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      marginTop: 6,
    },
    allHistoryText: { color: colors.blue, fontSize: 13, fontWeight: "600" },
    loadMoreRow: {
      minHeight: 48,
      alignItems: "center",
      justifyContent: "center",
      marginTop: 8,
    },
    loadMoreText: { color: colors.blue, fontSize: 13, fontWeight: "600" },
    transcript: { padding: 16, gap: 8 },
    messageRow: { alignItems: "flex-start" },
    messageRowOutbound: { alignItems: "flex-end" },
    messageBubble: {
      maxWidth: "82%",
      backgroundColor: colors.paper,
      borderRadius: uiTokens.radius.md,
      paddingHorizontal: 12,
      paddingVertical: 8,
      borderWidth: StyleSheet.hairlineWidth,
      borderColor: colors.rule,
    },
    messageBubbleOutbound: { backgroundColor: colors.blueWash },
    messageText: { color: colors.ink, fontSize: 13, lineHeight: 19 },
    historyImage: { width: 160, height: 160 },
    messageNonText: { color: colors.muted, fontSize: 12 },
    messageTime: { color: colors.muted, fontSize: 10, marginTop: 4 },
    goToConversationButton: {
      marginTop: 18,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      gap: 8,
      backgroundColor: colors.primary,
      borderRadius: uiTokens.radius.md,
      paddingHorizontal: 20,
      paddingVertical: 12,
      alignSelf: "stretch",
    },
    goToConversationButtonPressed: { opacity: 0.85 },
    goToConversationText: {
      color: colors.onPrimary,
      fontSize: 15,
      fontWeight: "700",
    },
  });
