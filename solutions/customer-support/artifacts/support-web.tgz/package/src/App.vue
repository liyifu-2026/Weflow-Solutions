<script setup lang="ts">
import ConversationsView from "./views/ConversationsView.vue";
</script>

<template>
  <ConversationsView />
</template>
