import { fileURLToPath, URL } from "node:url";
import { defineConfig } from "vite";
import vue from "@vitejs/plugin-vue";

const CORE_API_TARGET = process.env.CORE_API_TARGET || "http://127.0.0.1:3100";

export default defineConfig({
  base: "/support/",
  plugins: [vue()],
  resolve: {
    alias: {
      "@": fileURLToPath(new URL("./src", import.meta.url)),
    },
  },
  server: {
    port: 5174,
    host: true,
    proxy: {
      "/api": {
        target: CORE_API_TARGET,
        changeOrigin: true,
        secure: false,
      },
    },
  },
  preview: {
    port: 4174,
    host: true,
    proxy: {
      "/api": {
        target: CORE_API_TARGET,
        changeOrigin: true,
        secure: false,
      },
    },
  },
});
